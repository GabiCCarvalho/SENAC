
CREATE DATABASE db_AlyPet ON PRIMARY
(NAME = db_AlyPet,

FILENAME = 'C:\SQL\db_AlyPet.mdf',
SIZE = 6MB,
MAXSIZE = 15MB,
FILEGROWTH = 10%)
LOG ON (
NAME = db_AlyPet_log,
FILENAME = 'C:\SQL\db_AlyPet_log.ldf',
SIZE = 1MB, FILEGROWTH = 1MB)
GO

CREATE TABLE tbl_Cadastro (
CPF VARCHAR (11) PRIMARY KEY NOT NULL,
Nome_User VARCHAR (30) NOT NULL,
Data_Nascimento DATE NOT NULL,
Nome_Cliente VARCHAR (50) NOT NULL,
Sobrenome_Cliente VARCHAR(50) NOT NULL,
Email_cliente VARCHAR(50) NOT NULL,
Telefone SMALLINT NOT NULL,
Senha VARCHAR (25) NOT NULL,
Cidade VARCHAR (50) NOT NULL,
Bairro VARCHAR (50) NOT NULL,
CEP VARCHAR (8) NOT NULL,
Numero VARCHAR(10) NOT NULL,
);

CREATE TABLE tbl_logon(
ID_user SMALLINT IDENTITY NOT NULL,
Nome_user VARCHAR(20),
Senha VARCHAR(255)
CONSTRAINT pk_id_user PRIMARY KEY (ID_user)
);


CREATE TABLE tbl_cadPet (
ID_Animal SMALLINT PRIMARY KEY IDENTITY (100,1),
Tamanho VARCHAR(20) NOT NULL,
Peso VARCHAR(10) NOT NULL,
Nome_Animal VARCHAR(50) NOT NULL,
Ra�a SMALLINT NOT NULL,
Idade VARCHAR(20) NOT NULL,
Observacao VARCHAR(50) NOT NULL,
CPF VARCHAR (11) NOT NULL,
CONSTRAINT fk_cpf FOREIGN KEY (CPF)
	REFERENCES tbl_Cadastro (CPF) ON DELETE CASCADE,
);


CREATE TABLE tbl_DonoAnimal(
ID_Relacao SMALLINT PRIMARY KEY IDENTITY (1000,1),
ID_animal SMALLINT NOT NULL,
CPF VARCHAR (11) NOT NULL,
ID_Servicos SMALLINT NOT NULL,
CONSTRAINT fk_id_animal FOREIGN KEY (ID_Animal)
	REFERENCES tbl_cadPet (ID_Animal) ON DELETE CASCADE,
CONSTRAINT fk_CPF_relacao FOREIGN KEY (CPF)
	REFERENCES tbl_Cadastro (CPF),
CONSTRAINT fk_Id_Servicos FOREIGN KEY (ID_Servicos)
REFERENCES tbl_Servicos (ID_Servicos) ON DELETE CASCADE
);

CREATE TABLE tbl_Acessorio (
ID_Acessorios SMALLINT PRIMARY KEY IDENTITY (100,1),
Nome_Acessorios VARCHAR (50),
Preco_Acessorios MONEY NOT NULL,
);

CREATE TABLE tbl_Farmacia (
ID_Remedio SMALLINT PRIMARY KEY IDENTITY,
Nome_Remedio VARCHAR (50),
Preco_Farmacia MONEY NOT NULL
);

CREATE TABLE tbl_Servicos (
ID_Servicos SMALLINT PRIMARY KEY IDENTITY (100,1),
Nome_Servicos VARCHAR (50),
Preco_Servicos MONEY NOT NULL,
);
 

CREATE TABLE tbl_Racao (
ID_Ra��o SMALLINT PRIMARY KEY IDENTITY(100,1),
Nome_Racao VARCHAR (100),
Preco_Racao MONEY NOT NULL
);

INSERT INTO tbl_Racao 
(Nome_Racao, Preco_Racao )
VALUES
('Carne para c�es adulto', 25.19),
('Frango para c�es adulto', 25.19 ),
('Salm�o para c�es adulto', 25.19 ),
('Carne para c�es filhote', 27.20 ),
('Frango para c�es filhote', 27.20 ),
('Salm�o para c�es filhote', 27.20 ),
('Carne para gato filhote', 27.20 ),
('Frango para gato filhote', 27.20 ),
('Salm�o para gato filhote', 27.20 ),
('Carne para gato adulto', 25.19 ),
('Frango para gato adulto', 25.19 ),
('Salm�o para gato adulto', 25.19),
('Ra��o peixe Granulado', 15.50),
('Ra��o peixe Flocos', 15.50);

INSERT INTO tbl_Acessorio
(Nome_Acessorios, Preco_Acessorios )
VALUES
('Coleira para c�es adulto', 60.00),
('Coleira para c�es filhote', 56.20 ),
('Coleira para gato adulto', 54.20 ),
('Coleira para gato filhote', 52.20 ),
('Roupa para c�es PP', 25.00 ),
('Roupa para c�es P', 28.00 ),
('Roupa para c�es M', 30.00),
('Roupa para c�es G', 40.00 ),
('Roupa para gato PP', 25.00 ),
('Roupa para gato P', 28.00 ),
('Roupa para gato M', 30.00 ),
('Roupa para gato G', 40.00 ),
('Recipiente para Ra��o c�es e gatos', 60.30 ),
('Bebedouro', 75.50),
('Casinha madeira para c�es Pequena', 75.00 ),
('Casinha madeira para c�es M�dia', 90.00 ),
('Casinha madeira para c�es Grande', 250.00 ),
('Caminha para c�es Pequena', 50.00),
('Caminha para c�es M�dia', 80.00),
('Caminha para c�es Grande', 95.00),
('Caminha para gato M�dia', 80.00),
('Tapete higi�nico', 65.00),
('Shampoo (2 em 1) para c�es e gatos', 45.00),
('Pelucia', 30.00),
('Ossinho', 20.00),
('bolinha', 25.00),
('Arranhador', 45.00),
('Aquario', 40.00),
('Filtro para peixe', 36.00),
('Enfeites', 20.00),
('Pedrinhas', 25.00);

INSERT INTO tbl_Farmacia 
(Nome_Remedio, Preco_Farmacia )
VALUES
('Antipulgas para c�es', 80.00),
('Vermifugo para c�es', 60.00 ),
('Antiparasita para c�es', 55.50),
('Antipulgas para gato', 80.00),
('Vermifugo para gato', 60.00 ),
('Antiparasita para gato', 55.50);

INSERT INTO tbl_Servicos
(Nome_Servicos, Preco_Servicos )
VALUES
('Banho porte pequeno', 50.00),
('Banho porte m�dio', 75.00 ),
('Banho porte grande', 90.00),
('Banho e Tosa porte pequeno', 80.00),
('Banho e Tosa porte m�dio', 95.00 ),
('Banho e Tosa porte grande', 120.00),
('TaxiDog at� 6km', 12.00 );




SELECT * FROM tbl_Acessorio;
SELECT * FROM tbl_Farmacia;
SELECT * FROM tbl_Servicos;
SELECT * FROM tbl_Racao;